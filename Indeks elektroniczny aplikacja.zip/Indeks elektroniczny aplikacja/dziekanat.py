import mysql.connector
import sys
from tkinter import *
from functools import partial
import random


def dziekanat_main(id_zalogowany, logowanie_pasy, root):

    logowanie_pasy.grid_forget()
    global dziekanat_main
    dziekanat_main = LabelFrame(root, text="DZIEKANAT MAIN")
    dziekanat_main.grid(row=0, column=0)

    zarzadzaj_studentami_btn = Button(dziekanat_main, text="ZARZĄDZAJ STUDENTAMI", padx=30, pady=30, command=partial(zarzadzaj_studentami, root))
    zarzadzaj_prowadzacymi_btn = Button(dziekanat_main, text="ZARZĄDZAJ PROWADZĄCYMI", padx=30, pady=30, command=partial(zarzadzaj_prowadzacymi, root))
    zarzadzaj_kursami_btn = Button(dziekanat_main, text="ZARZĄDZAJ KURSAMI", padx=30, pady=30, command=partial(zarzadzaj_kursami, root))
    zarzadzaj_kierunkami_btn = Button(dziekanat_main, text="ZARZĄDZAJ KIERUNKAMI", padx=30, pady=30, command=partial(zarzadzaj_kierunekami, root))
    zmiana_hasla_btn = Button(dziekanat_main, text="ZMIEŃ HASŁO", command=partial(zmien_haslo, id_zalogowany, root))
    wyloguj_btn = Button(dziekanat_main, text="Wyloguj", command=wyloguj)
    zarzadzaj_studentami_btn.grid(row=0, column=0)
    zarzadzaj_prowadzacymi_btn.grid(row=1, column=0)
    zarzadzaj_kursami_btn.grid(row=1, column=1)
    zarzadzaj_kierunkami_btn.grid(row=0, column=1)
    zmiana_hasla_btn.grid(row=2, column=98)
    wyloguj_btn.grid(row=2, column=99)

def wyloguj():
    sys.exit()

def zmien_haslo(id_zalogowany, root):
    dziekanat_main.grid_forget()
    global zmien_haslo_frame
    zmien_haslo_frame = LabelFrame(root, text="ZMIEŃ HASŁO")
    zmien_haslo_frame.grid(row=0, column=0)

    stare_haslo_label = Label(zmien_haslo_frame, text="Stare hasło: ")
    nowe_haslo_label = Label(zmien_haslo_frame, text="Nowe hasło: ")
    potwierdz_haslo_label = Label(zmien_haslo_frame, text="Potwierdź hasło: ")

    global stare_haslo_entry
    stare_haslo_entry = Entry(zmien_haslo_frame, width=40)
    global nowe_haslo_entry
    nowe_haslo_entry = Entry(zmien_haslo_frame, width=40)
    global potwierdz_haslo_entry
    potwierdz_haslo_entry = Entry(zmien_haslo_frame, width=40)
    zatwierdz_btn = Button(zmien_haslo_frame, text="Zatwierdź", command=partial(zatwierdz_zmiane_hasla, id_zalogowany))
    wstecz_btn = Button(zmien_haslo_frame, text="Wstecz", command=wstecz_do_dziekanat_main_haslo)

    stare_haslo_label.grid(row=0, column=0)
    nowe_haslo_label.grid(row=1, column=0)
    potwierdz_haslo_label.grid(row=2, column=0)
    stare_haslo_entry.grid(row=0, column=1)
    nowe_haslo_entry.grid(row=1, column=1)
    potwierdz_haslo_entry.grid(row=2, column=1)
    zatwierdz_btn.grid(row=3, column=1)
    wstecz_btn.grid(row=3, column=2)

def zatwierdz_zmiane_hasla(id_zalogowany):
    wprowadzone_haslo = stare_haslo_entry.get()
    nowe_haslo = nowe_haslo_entry.get()
    potwierdz_nowe_haslo = potwierdz_haslo_entry.get()
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()
    query = "SELECT haslo FROM logowanie WHERE id_logowanie = %s"
    cursor.execute(query, (id_zalogowany))
    for haslo in cursor:
        obecne_haslo = haslo[0]
    if (obecne_haslo == wprowadzone_haslo) and (nowe_haslo == potwierdz_nowe_haslo):
        query = "UPDATE logowanie SET haslo = %s WHERE id_logowanie = %s"
        cursor.execute(query, (nowe_haslo, id_zalogowany[0]))
        mydb.commit()
        dobre_dane_label = Label(zmien_haslo_frame, text="Hasło zaktualizowane poprawnie", fg="green")
        dobre_dane_label.grid(row=4, column=1)
    else:
        zle_dane_label = Label(zmien_haslo_frame, text="Podano złe dane", fg="red")
        zle_dane_label.grid(row=4, column=1)

def zarzadzaj_kursami(root):
    dziekanat_main.grid_forget()
    global zarzadzaj_kursami_frame
    zarzadzaj_kursami_frame = LabelFrame(root, text="ZARZĄDZAJ KURSAMI")
    zarzadzaj_kursami_frame.grid(row=0, column=0)

    dodaj_kurs_btn = Button(zarzadzaj_kursami_frame, text="Dodaj kurs", padx=30, pady=30, command=partial(dodaj_kurs, root))
    wyswietl_kurs = Button(zarzadzaj_kursami_frame, text="Wyświetl kursy", padx=30, pady=30, command=partial(wyswietl_kursy, root))
    dodaj_kurs_btn.grid(row=0, column=0)
    wyswietl_kurs.grid(row=0, column=1)
    wstecz_btn = Button(zarzadzaj_kursami_frame, text="Wstecz", command=wstecz_do_main_dziekanat_zarzadzaj_kursami)
    wstecz_btn.grid(row=2, column=2)

def wyswietl_kursy(root):
    zarzadzaj_kursami_frame.grid_forget()
    global wyswietl_kursy_frame
    wyswietl_kursy_frame = LabelFrame(root, text="ZARZĄDZAJ KURSAMI")
    wyswietl_kursy_frame.grid(row=0, column=0)
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()
    query = "SELECT id_kursy, nazwa_kursu, termin, id_prowadzacy, id_kierunek FROM kursy"
    cursor.execute(query)
    lista_numer = []
    lista_nazwa = []
    lista_termin = []
    lista_nr_prowadzacy = []
    lista_imie = []
    lista_nazwisko = []
    lista_nr_kierunek = []
    lista_kierunek = []
    for (id_kursy, nazwa_kursu, termin, id_prowadzacy, id_kierunek) in cursor:
        lista_numer.append(id_kursy)
        lista_nazwa.append(nazwa_kursu)
        lista_termin.append(termin)
        lista_nr_prowadzacy.append(id_prowadzacy)
        lista_nr_kierunek.append((id_kierunek))
    for i in range(len(lista_nr_prowadzacy)):
        query = "SELECT imie, nazwisko FROM prowadzacy WHERE id_prowadzacy = %s"
        cursor.execute(query, (lista_nr_prowadzacy[i],))
        for (imie, nazwisko) in cursor:
            lista_imie.append(imie)
            lista_nazwisko.append(nazwisko)
    for i in range(len(lista_nr_kierunek)):
        query = "SELECT nazwa_kierunku FROM kierunki WHERE id_kierunki = %s"
        cursor.execute(query, (lista_nr_kierunek[i],))
        for (nazwa) in cursor:
            lista_kierunek.append(nazwa[0])

    j = 1
    wybrany_kurs = IntVar()

    nazwa_kursu_label = Label(wyswietl_kursy_frame, text="Nazwa kursu:")
    termin_label = Label(wyswietl_kursy_frame, text="Termin:")
    prowadzacy_label = Label(wyswietl_kursy_frame, text="Prowadzący:")
    kierunek_z_kursu_label = Label(wyswietl_kursy_frame, text="Kierunek:")
    nazwa_kursu_label.grid(row=0, column=0)
    termin_label.grid(row=0, column=1)
    prowadzacy_label.grid(row=0, column=2)
    kierunek_z_kursu_label.grid(row=0, column=3)


    for i in range(len(lista_numer)):
        nazwa_kursu_label = Label(wyswietl_kursy_frame, text=str(lista_nazwa[i]))
        termin_label = Label(wyswietl_kursy_frame, text=str(lista_termin[i]))
        prowadzacy_label = Label(wyswietl_kursy_frame, text=str(lista_imie[i] + " " + str(lista_nazwisko[i])))
        kierunek_z_kursu_label = Label(wyswietl_kursy_frame, text=str(lista_kierunek[i]))
        separator = Label(wyswietl_kursy_frame, text="                              ")

        Radiobutton(wyswietl_kursy_frame, variable=wybrany_kurs, value=lista_numer[i]).grid(row=j, column=5)

        nazwa_kursu_label.grid(row=j, column=0)
        termin_label.grid(row=j, column=1)
        prowadzacy_label.grid(row=j, column=2)
        kierunek_z_kursu_label.grid(row=j, column=3)
        separator.grid(row=j+1, column=4)
        j += 2

    wstecz_btn = Button(wyswietl_kursy_frame, text="Wstecz", command=wstecz_do_zarzadzaj_kursami_wyswietl_kursy)
    wstecz_btn.grid(row=99, column=99)
    usun_kurs_btn = Button(wyswietl_kursy_frame, text="Usuń kurs", command=partial(usun_kurs, wybrany_kurs))
    usun_kurs_btn.grid(row=98, column=1)
    edytuj_kurs_btn = Button(wyswietl_kursy_frame, text="Edytuj kurs", command=partial(edytuj_kurs, root, wybrany_kurs))
    edytuj_kurs_btn.grid(row=98, column=4)

def usun_kurs(wybrany_kurs):
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()
    numer = wybrany_kurs.get()
    query = "DELETE FROM zapisany_na_kurs WHERE id_kursu = %s"
    cursor.execute(query, (numer,))
    mydb.commit()
    query = "DELETE FROM kursy WHERE id_kursy = %s"
    cursor.execute(query, (numer,))
    mydb.commit()
    powodzenie_label = Label(wyswietl_kursy_frame, text="Usunięto kurs", fg="red")
    powodzenie_label.grid(row=99, column=2)

def dodaj_kurs(root):
    zarzadzaj_kursami_frame.grid_forget()
    global dodaj_kurs_frame
    dodaj_kurs_frame = LabelFrame(root, text="DODAJ PROWADZĄCEGO")
    dodaj_kurs_frame.grid(row=0, column=0)

    nazwa_label = Label(dodaj_kurs_frame, text="Nazwa: ")
    termin_label = Label(dodaj_kurs_frame, text="Termin: ")
    opis_label = Label(dodaj_kurs_frame, text="Opis: ")
    global nazwa_entry
    nazwa_entry = Entry(dodaj_kurs_frame)
    global termin_entry
    termin_entry = Entry(dodaj_kurs_frame)
    global opis_entry
    opis_entry = Entry(dodaj_kurs_frame)
    nazwa_label.grid(row=0, column=0)
    termin_label.grid(row=2, column=0)
    opis_label.grid(row=4, column=0)
    nazwa_entry.grid(row=1, column=0)
    termin_entry.grid(row=3, column=0)
    opis_entry.grid(row=5, column=0)

    wstecz_btn = Button(dodaj_kurs_frame, text="Wstecz", command=wstecz_do_zarzadzaj_kursami_dodaj_kurs)
    wstecz_btn.grid(row=7, column=3)
    zatwierdz_nowy_kurs = Button(dodaj_kurs_frame, text="Zatwierdź", command=partial(kierunek_nowy_kurs, root))
    zatwierdz_nowy_kurs.grid(row=6, column=0)

def kierunek_nowy_kurs(root):
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()
    dodaj_kurs_frame.grid_forget()
    global kierunek_dodaj_kurs_frame
    kierunek_dodaj_kurs_frame = LabelFrame(root, text="WYBIERZ KIERUNEK")
    kierunek_dodaj_kurs_frame.grid(row=0, column=0)
    query = "SELECT id_kierunki, nazwa_kierunku FROM kierunki"
    cursor.execute(query)
    i = 0
    wybrany_kierunek = IntVar()
    for (id_kierunki, nazwa_kierunku) in cursor:
        nazwa_label = Label(kierunek_dodaj_kurs_frame, text=nazwa_kierunku)
        separator=Label(kierunek_dodaj_kurs_frame, text="                             " )
        Radiobutton(kierunek_dodaj_kurs_frame, variable=wybrany_kierunek, value=id_kierunki).grid(row=i, column=2)

        nazwa_label.grid(row=i, column=0)
        separator.grid(row=i+1, column=0)
        i += 2
    wstecz_btn = Button(kierunek_dodaj_kurs_frame, text="Wstecz", command=wstecz_do_dodaj_kurs_kierunek)
    wstecz_btn.grid(row=99, column=99)
    zatwierdz_btn = Button(kierunek_dodaj_kurs_frame, text="Wybierz", command=partial(prowadzacy_nowy_kurs, wybrany_kierunek, root))
    zatwierdz_btn.grid(row=99, column=98)

def prowadzacy_nowy_kurs(wybrany_kierunek, root):
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()
    kierunek_dodaj_kurs_frame.grid_forget()
    global prowadzacy_dodaj_kurs_frame
    prowadzacy_dodaj_kurs_frame = LabelFrame(root, text="WYBIERZ PROWADZĄCEGO")
    prowadzacy_dodaj_kurs_frame.grid(row=0, column=0)

    query = "SELECT id_prowadzacy, imie, nazwisko FROM prowadzacy"
    cursor.execute(query)
    id_kierunki = wybrany_kierunek.get()
    i = 0
    wybrany_prowadzacy = IntVar()
    for (id_prowadzacy, imie, nazwisko) in cursor:
        imie_label = Label(prowadzacy_dodaj_kurs_frame, text=imie)
        nazwisko_label = Label(prowadzacy_dodaj_kurs_frame, text=nazwisko)

        separator=Label(prowadzacy_dodaj_kurs_frame, text="                             " )
        Radiobutton(prowadzacy_dodaj_kurs_frame, variable=wybrany_prowadzacy, value=id_prowadzacy).grid(row=i, column=2)

        imie_label.grid(row=i, column=0)
        nazwisko_label.grid(row=i, column=1)
        separator.grid(row=i+2, column=0)
        i += 3

    wstecz_btn = Button(prowadzacy_dodaj_kurs_frame, text="Wstecz", command=wstecz_do_dodaj_kurs_prowadzacy)
    wstecz_btn.grid(row=99, column=99)
    zatwierdz_nowy_kurs_btn = Button(prowadzacy_dodaj_kurs_frame, text="Wybierz prowadzącego", command=partial(zatwierdz_nowy_kurs, id_kierunki, wybrany_prowadzacy))
    zatwierdz_nowy_kurs_btn.grid(row=98, column=0)

def zatwierdz_nowy_kurs(id_kierunki, wybrany_prowadzacy):
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()

    nazwa = nazwa_entry.get()
    termin = termin_entry.get()
    opis = opis_entry.get()
    id_prowadzacy = wybrany_prowadzacy.get()
    query = "INSERT INTO kursy (nazwa_kursu, termin, opis, id_prowadzacy, id_kierunek) VALUES (%s, %s, %s, %s, %s)"
    cursor.execute(query, (nazwa, termin, opis, id_prowadzacy, id_kierunki))
    mydb.commit()

    powodzenie_label = Label(prowadzacy_dodaj_kurs_frame, text="Dodano kurs", fg="green")
    powodzenie_label.grid(row=100, column=0)

def zarzadzaj_prowadzacymi(root):
    dziekanat_main.grid_forget()
    global zarzadzaj_prowadzacymi_frame
    zarzadzaj_prowadzacymi_frame = LabelFrame(root, text="ZARZĄDZAJ PROWADZĄCYMI")
    zarzadzaj_prowadzacymi_frame.grid(row=0, column=0)

    dodaj_prowadzacego_btn = Button(zarzadzaj_prowadzacymi_frame, text="Dodaj prowadzącego", padx=30, pady=30, command=partial(dodaj_prowadzacego, root))
    wybierz_prowadzacego_btn = Button(zarzadzaj_prowadzacymi_frame, text="Wybierz prowadzącego", padx=30, pady=30, command=partial(wybierz_prowadzacego, root))
    dodaj_prowadzacego_btn.grid(row=0, column=0)
    wybierz_prowadzacego_btn.grid(row=0, column=1)
    wstecz_btn = Button(zarzadzaj_prowadzacymi_frame, text="Wstecz", command=wstecz_do_main_dziekanat_zarzadzaj_prowadzacymi)
    wstecz_btn.grid(row=2, column=2)

def wybierz_prowadzacego(root):
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()
    zarzadzaj_prowadzacymi_frame.grid_forget()
    global wybierz_prowadzacego_frame
    wybierz_prowadzacego_frame = LabelFrame(root, text="WYBIERZ PROWADZĄCEGO")
    wybierz_prowadzacego_frame.grid(row=0, column=0)
    query = "SELECT id_prowadzacy, imie, nazwisko FROM prowadzacy"
    cursor.execute(query, )
    i = 0
    wybrany_prowadzacy = IntVar()

    for (id_prowadzacy, imie, nazwisko) in cursor:
        imie_label = Label(wybierz_prowadzacego_frame, text=imie)
        nazwisko_label = Label(wybierz_prowadzacego_frame, text=nazwisko)
        Radiobutton(wybierz_prowadzacego_frame, variable=wybrany_prowadzacy, value=id_prowadzacy).grid(row=i, column=3)
        imie_label.grid(row=i, column=0)
        nazwisko_label.grid(row=i, column=1)
        i += 1

    wstecz_btn = Button(wybierz_prowadzacego_frame, text="Wstecz", command=wstecz_do_zarzadzaj_prowadzacymi_wybierz_prowadzacego)
    wstecz_btn.grid(row=99, column=99)
    zatwierdz_btn = Button(wybierz_prowadzacego_frame, text="Wyświetl dane", command=partial(wyswietl_dane_prowadzacego, root, wybrany_prowadzacy))
    zatwierdz_btn.grid(row=98, column=1)
    zatwierdz_btn = Button(wybierz_prowadzacego_frame, text="Usuń prowadzącego",command=partial(usun_prowadzacego, wybrany_prowadzacy))
    zatwierdz_btn.grid(row=98, column=2)

def usun_prowadzacego(wybrany_prowadzacy):
    zatwierdz_btn = Button(wybierz_prowadzacego_frame, text="Potwierdź usunięcie prowadzącego",
    command=partial(usun_prowadzacego_potwierdz, wybrany_prowadzacy))
    zatwierdz_btn.grid(row=98, column=2)

def usun_prowadzacego_potwierdz(wybrany_prowadzacy):
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()
    prowadzacy = wybrany_prowadzacy.get()
    query = "DELETE FROM prowadzacy WHERE id_prowadzacy = %s"
    cursor.execute(query, (prowadzacy,))
    mydb.commit()
    powodzenie_label = Label(wybierz_prowadzacego_frame, text="Usunięto prowadzącego", fg="red")
    powodzenie_label.grid(row=100, column=0)

def wyswietl_dane_prowadzacego(root, wybrany_prowadzacy):
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()

    wybierz_prowadzacego_frame.grid_forget()
    global wyswietl_dane_prowadzacego_frame
    wyswietl_dane_prowadzacego_frame = LabelFrame(root, text="PROWADZĄCY")
    wyswietl_dane_prowadzacego_frame.grid(row=0, column=0)
    global prowadzacy
    prowadzacy = wybrany_prowadzacy.get()

    query = "SELECT id_prowadzacy, imie, nazwisko, pesel, email FROM prowadzacy WHERE id_prowadzacy = %s"
    cursor.execute(query, (prowadzacy,))
    for (id_prowadzacy, imie, nazwisko, pesel, email,) in cursor:
        imie_label = Label(wyswietl_dane_prowadzacego_frame, text="Imię: "+imie)
        nazwisko_label = Label(wyswietl_dane_prowadzacego_frame, text="Nazwisko: "+nazwisko)
        pesel_label = Label(wyswietl_dane_prowadzacego_frame, text="Pesel: "+pesel)
        email_label = Label(wyswietl_dane_prowadzacego_frame, text="Adres e-mail: "+email)
        imie_label.grid(row=0, column=0)
        nazwisko_label.grid(row=1, column=0)
        pesel_label.grid(row=2, column=0)
        email_label.grid(row=3, column=0)

    wstecz_btn = Button(wyswietl_dane_prowadzacego_frame, text="Wstecz", command=wstecz_do_wybierz_prowadzacego_wyswietl_dane_prowadzacego)
    wstecz_btn.grid(row=5, column=3)
    edytuj_dane_btn = Button(wyswietl_dane_prowadzacego_frame, text="Edytuj dane prowadzącego", command=partial(edytuj_dane_prowadzacego, root))
    edytuj_dane_btn.grid(row=4, column=0)

def edytuj_dane_prowadzacego(root):
    wyswietl_dane_prowadzacego_frame.grid_forget()
    global edytuj_dane_prowadzacego
    edytuj_dane_prowadzacego = LabelFrame(root, text="EDYTUJ DANE PROWADZĄCEGO")
    edytuj_dane_prowadzacego.grid(row=0, column=0)

    imie_label = Label(edytuj_dane_prowadzacego, text="Imię: ")
    nazwisko_label = Label(edytuj_dane_prowadzacego, text="Nazwisko: ")
    pesel_label = Label(edytuj_dane_prowadzacego, text="Pesel: ")
    email_label = Label(edytuj_dane_prowadzacego, text="Adres e-mail: ")
    imie_entry = Entry(edytuj_dane_prowadzacego)
    nazwisko_entry = Entry(edytuj_dane_prowadzacego)
    pesel_entry = Entry(edytuj_dane_prowadzacego)
    email_entry = Entry(edytuj_dane_prowadzacego)
    imie_label.grid(row=0, column=0)
    nazwisko_label.grid(row=2, column=0)
    pesel_label.grid(row=4, column=0)
    email_label.grid(row=6, column=0)
    imie_entry.grid(row=1, column=0)
    nazwisko_entry.grid(row=3, column=0)
    pesel_entry.grid(row=5, column=0)
    email_entry.grid(row=7, column=0)

    zatwierdz_edycje_prowadzacego_btn = Button(edytuj_dane_prowadzacego, text="Zatwierdź", command=partial(zawtierdz_edycje_prowadzacego, imie_entry, nazwisko_entry,pesel_entry,email_entry))
    zatwierdz_edycje_prowadzacego_btn.grid(row=14, column=0)
    wstecz_btn = Button(edytuj_dane_prowadzacego, text="Wstecz", command=wstecz_do_wyswietl_dane_prowadzacego)
    wstecz_btn.grid(row=15, column=3)

def zawtierdz_edycje_prowadzacego(imie_entry, nazwisko_entry, pesel_entry, email_entry):
    input_imie = imie_entry.get()
    input_nazwisko = nazwisko_entry.get()
    input_pesel = pesel_entry.get()
    input_email = email_entry.get()
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()
    query = "UPDATE prowadzacy SET imie = %s, nazwisko = %s, pesel = %s, email = %s WHERE id_prowadzacy = %s"
    cursor.execute(query, (input_imie, input_nazwisko, input_pesel, input_email, prowadzacy,))
    mydb.commit()
    powodzenie_label = Label(edytuj_dane_prowadzacego, text="Zatwierdzono zmiany", fg="green")
    powodzenie_label.grid(row=100, column=0)
    wstecz_btn = Button(edytuj_dane_prowadzacego, text="Wstecz", command=wstecz_do_wyswietl_dane_prowadzacego)
    wstecz_btn.grid(row=15, column=3)

def dodaj_prowadzacego(root):
    zarzadzaj_prowadzacymi_frame.grid_forget()
    global dodaj_prowadzacego_frame
    dodaj_prowadzacego_frame = LabelFrame(root, text="DODAJ PROWADZĄCEGO")
    dodaj_prowadzacego_frame.grid(row=0, column=0)

    imie_label = Label(dodaj_prowadzacego_frame, text="Imię: ")
    nazwisko_label = Label(dodaj_prowadzacego_frame, text="Nazwisko: ")
    pesel_label = Label(dodaj_prowadzacego_frame, text="Pesel: ")
    email_label = Label(dodaj_prowadzacego_frame, text="Adres e-mail: ")
    imie_entry = Entry(dodaj_prowadzacego_frame)
    nazwisko_entry = Entry(dodaj_prowadzacego_frame)
    pesel_entry = Entry(dodaj_prowadzacego_frame)
    email_entry = Entry(dodaj_prowadzacego_frame)
    imie_label.grid(row=0, column=0)
    nazwisko_label.grid(row=2, column=0)
    pesel_label.grid(row=6, column=0)
    email_label.grid(row=8, column=0)
    imie_entry.grid(row=1, column=0)
    nazwisko_entry.grid(row=3, column=0)
    pesel_entry.grid(row=7, column=0)
    email_entry.grid(row=9, column=0)

    wstecz_btn = Button(dodaj_prowadzacego_frame, text="Wstecz", command=wstecz_do_zarzadzaj_prowadzacymi_dodaj_prowadzacego)
    wstecz_btn.grid(row=11, column=3)
    zatwierdz_btn = Button(dodaj_prowadzacego_frame, text="Zatwierdź", command=partial(zatwierdz_nowego_prowadzacego,imie_entry,nazwisko_entry,pesel_entry,email_entry))
    zatwierdz_btn.grid(row=10, column=0)

def zatwierdz_nowego_prowadzacego(imie_entry,nazwisko_entry,pesel_entry,email_entry):
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()

    nr_login = random.randint(100000, 999999)
    query = "INSERT INTO logowanie (login, haslo) VALUES (%s, %s)"
    cursor.execute(query, ("p" + str(nr_login), "p" + str(nr_login)))
    mydb.commit()
    input_imie=imie_entry.get()
    input_nazwisko=nazwisko_entry.get()
    input_pesel=pesel_entry.get()
    input_email=email_entry.get()
    last_id_logowanie = cursor.lastrowid
    query = "INSERT INTO prowadzacy (imie, nazwisko, pesel, email, id_logowanie) VALUES (%s, %s, %s, %s, %s)"
    cursor.execute(query, (input_imie, input_nazwisko, input_pesel, input_email, last_id_logowanie))
    mydb.commit()
    powodzenie_label = Label(dodaj_prowadzacego_frame, text="Dodano prowadzącego", fg="green")
    powodzenie_label.grid(row=100, column=0)

def zarzadzaj_studentami(root):
    dziekanat_main.grid_forget()
    global zarzadzaj_studentami_frame
    zarzadzaj_studentami_frame = LabelFrame(root, text="ZARZĄDZAJ STUDENTAMI")
    zarzadzaj_studentami_frame.grid(row=0, column=0)

    dodaj_studenta_btn = Button(zarzadzaj_studentami_frame, text="Dodaj studenta", padx=30, pady=30, command=partial(dodaj_studenta, root))
    wybierz_studenta_btn = Button(zarzadzaj_studentami_frame, text="Wybierz studenta", padx=30, pady=30, command=partial(wybierz_studenta, root))
    dodaj_studenta_btn.grid(row=0, column=0)
    wybierz_studenta_btn.grid(row=0, column=1)
    wstecz_btn = Button(zarzadzaj_studentami_frame, text="Wstecz", command=wstecz_do_main_dziekanat_zarzadzaj_stuedntami)
    wstecz_btn.grid(row=2, column=2)

def wybierz_studenta(root):
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()

    zarzadzaj_studentami_frame.grid_forget()
    global wybierz_studenta_frame
    wybierz_studenta_frame = LabelFrame(root, text="WYBIERZ STUDENTA")
    wybierz_studenta_frame.grid(row=0, column=0)

    query = "SELECT id_student, imie, nazwisko, nr_indeksu FROM student"
    cursor.execute(query, )
    i = 0
    wybrany_student = IntVar()

    for (id_student, imie, nazwisko, nr_indeksu) in cursor:

        imie_label = Label(wybierz_studenta_frame, text=imie)
        nazwisko_label = Label(wybierz_studenta_frame, text=nazwisko)
        nr_indeksu_label = Label(wybierz_studenta_frame, text=nr_indeksu)

        Radiobutton(wybierz_studenta_frame, variable=wybrany_student, value=id_student).grid(row=i, column=3)
        imie_label.grid(row=i, column=0)
        nazwisko_label.grid(row=i, column=1)
        nr_indeksu_label.grid(row=i, column=2)
        i += 1

    wstecz_btn = Button(wybierz_studenta_frame, text="Wstecz", command=wstecz_do_zarzadzaj_stuedntami_wybierz_studenta)
    wstecz_btn.grid(row=99, column=99)
    zatwierdz_btn = Button(wybierz_studenta_frame, text="Wybierz studenta", command=partial(wyswietl_dane_studenta, root, wybrany_student))
    zatwierdz_btn.grid(row=99, column=1)

def wyswietl_dane_studenta(root, wybrany_student):
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()

    wybierz_studenta_frame.grid_forget()
    global wyswietl_dane_studenta_frame
    wyswietl_dane_studenta_frame = LabelFrame(root, text="STUDENTA")
    wyswietl_dane_studenta_frame.grid(row=0, column=0)
    global student
    student = wybrany_student.get()

    query = "SELECT id_student, imie, nazwisko, nr_indeksu, pesel, email, nr_telefonu, status FROM student WHERE id_student = %s"
    cursor.execute(query, (student,))
    for (id_student, imie, nazwisko, nr_indeksu, pesel, email, nr_telefonu, status) in cursor:
        imie_label = Label(wyswietl_dane_studenta_frame, text="Imię: "+imie)
        nazwisko_label = Label(wyswietl_dane_studenta_frame, text="Nazwisko: "+nazwisko)
        nr_indeksu_label = Label(wyswietl_dane_studenta_frame, text="Numer indeksu: "+nr_indeksu)
        pesel_label = Label(wyswietl_dane_studenta_frame, text="Pesel: "+pesel)
        email_label = Label(wyswietl_dane_studenta_frame, text="Adres e-mail: "+email)
        nr_telefonu_label = Label(wyswietl_dane_studenta_frame, text="Numer telefonu: "+ str(nr_telefonu))
        status_label = Label(wyswietl_dane_studenta_frame, text="Status: "+ status)
        imie_label.grid(row=0, column=0)
        nazwisko_label.grid(row=1, column=0)
        nr_indeksu_label.grid(row=2, column=0)
        pesel_label.grid(row=3, column=0)
        email_label.grid(row=4, column=0)
        nr_telefonu_label.grid(row=5, column=0)
        status_label.grid(row=6, column=0)
    wstecz_btn = Button(wyswietl_dane_studenta_frame, text="Wstecz", command=wstecz_do_wybierz_studenta_wyswietl_dane_studenta)
    wstecz_btn.grid(row=8, column=3)
    edytuj_dane_btn = Button(wyswietl_dane_studenta_frame, text="Edytuj dane studenta", command=partial(edytuj_dane_studenta, root))
    edytuj_dane_btn.grid(row=7, column=0)

def edytuj_dane_studenta(root):
    wyswietl_dane_studenta_frame.grid_forget()
    global edytuj_dane_studenta
    edytuj_dane_studenta = LabelFrame(root, text="EDYTUJ DANE STUDENTA")
    edytuj_dane_studenta.grid(row=0, column=0)

    imie_label = Label(edytuj_dane_studenta, text="Imię: ")
    nazwisko_label = Label(edytuj_dane_studenta, text="Nazwisko: ")
    nr_indeksu_label = Label(edytuj_dane_studenta, text="Numer indeksu: ")
    pesel_label = Label(edytuj_dane_studenta, text="Pesel: ")
    email_label = Label(edytuj_dane_studenta, text="Adres e-mail: ")
    nr_telefonu_label = Label(edytuj_dane_studenta, text="Numer telefonu: ")
    status_label = Label(edytuj_dane_studenta, text="Status: Aktywny/Zawieszony")
    imie_entry = Entry(edytuj_dane_studenta)
    nazwisko_entry = Entry(edytuj_dane_studenta)
    nr_indeksu_entry = Entry(edytuj_dane_studenta)
    pesel_entry = Entry(edytuj_dane_studenta)
    email_entry = Entry(edytuj_dane_studenta)
    nr_telefonu_entry = Entry(edytuj_dane_studenta)
    status_entry = Entry(edytuj_dane_studenta)
    imie_label.grid(row=0, column=0)
    nazwisko_label.grid(row=2, column=0)
    nr_indeksu_label.grid(row=4, column=0)
    pesel_label.grid(row=6, column=0)
    email_label.grid(row=8, column=0)
    nr_telefonu_label.grid(row=10, column=0)
    status_label.grid(row=12, column=0)
    imie_entry.grid(row=1, column=0)
    nazwisko_entry.grid(row=3, column=0)
    nr_indeksu_entry.grid(row=5, column=0)
    pesel_entry.grid(row=7, column=0)
    email_entry.grid(row=9, column=0)
    nr_telefonu_entry.grid(row=11, column=0)
    status_entry.grid(row=13, column=0)

    zatwierdz_edycje_studenta_btn = Button(edytuj_dane_studenta, text="Zatwierdź", command=partial(zawtierdz_edycje_studenta, imie_entry, nazwisko_entry,nr_indeksu_entry,pesel_entry,email_entry,nr_telefonu_entry,status_entry))
    zatwierdz_edycje_studenta_btn.grid(row=14, column=0)
    wstecz_btn = Button(edytuj_dane_studenta, text="Wstecz", command=wstecz_do_wyswietl_dane_studenta)
    wstecz_btn.grid(row=15, column=3)

def zawtierdz_edycje_studenta(imie_entry, nazwisko_entry,nr_indeksu_entry,pesel_entry,email_entry,nr_telefonu_entry,status_entry):
    input_imie=imie_entry.get()
    input_nazwisko=nazwisko_entry.get()
    input_nr_indeksu=nr_indeksu_entry.get()
    input_pesel=pesel_entry.get()
    input_email=email_entry.get()
    input_nr_telefonu=nr_telefonu_entry.get()
    input_status=status_entry.get()
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()
    query = "UPDATE student SET imie = %s, nazwisko = %s, nr_indeksu = %s, pesel = %s, email = %s, nr_telefonu = %s, status = %s WHERE id_student = %s"
    cursor.execute(query, (input_imie, input_nazwisko, input_nr_indeksu, input_pesel, input_email, input_nr_telefonu, input_status, student,))
    mydb.commit()
    powodzenie_label = Label(edytuj_dane_studenta, text="Zatwierdzono zmiany", fg="green")
    powodzenie_label.grid(row=100, column=0)

def dodaj_studenta(root):

    zarzadzaj_studentami_frame.grid_forget()
    global dodaj_studenta_frame
    dodaj_studenta_frame = LabelFrame(root, text="DODAJ STUDENTA")
    dodaj_studenta_frame.grid(row=0, column=0)

    imie_label = Label(dodaj_studenta_frame, text="Imię: ")
    nazwisko_label = Label(dodaj_studenta_frame, text="Nazwisko: ")
    nr_indeksu_label = Label(dodaj_studenta_frame, text="Numer indeksu: ")
    pesel_label = Label(dodaj_studenta_frame, text="Pesel: ")
    email_label = Label(dodaj_studenta_frame, text="Adres e-mail: ")
    nr_telefonu_label = Label(dodaj_studenta_frame, text="Numer telefonu: ")
    status_label = Label(dodaj_studenta_frame, text="Status: Aktywny/Zawieszony")
    imie_entry = Entry(dodaj_studenta_frame)
    nazwisko_entry = Entry(dodaj_studenta_frame)
    nr_indeksu_entry = Entry(dodaj_studenta_frame)
    pesel_entry = Entry(dodaj_studenta_frame)
    email_entry = Entry(dodaj_studenta_frame)
    nr_telefonu_entry = Entry(dodaj_studenta_frame)
    status_entry = Entry(dodaj_studenta_frame)
    imie_label.grid(row=0, column=0)
    nazwisko_label.grid(row=2, column=0)
    nr_indeksu_label.grid(row=4, column=0)
    pesel_label.grid(row=6, column=0)
    email_label.grid(row=8, column=0)
    nr_telefonu_label.grid(row=10, column=0)
    status_label.grid(row=12, column=0)
    imie_entry.grid(row=1, column=0)
    nazwisko_entry.grid(row=3, column=0)
    nr_indeksu_entry.grid(row=5, column=0)
    pesel_entry.grid(row=7, column=0)
    email_entry.grid(row=9, column=0)
    nr_telefonu_entry.grid(row=11, column=0)
    status_entry.grid(row=13, column=0)

    wstecz_btn = Button(dodaj_studenta_frame, text="Wstecz", command=wstecz_do_zarzadzaj_studentami_dodaj_studenta)
    wstecz_btn.grid(row=15, column=3)
    zatwierdz_btn = Button(dodaj_studenta_frame, text="Zatwierdź", command=partial(zatwierdz_nowego_studenta,imie_entry,nazwisko_entry,nr_indeksu_entry,pesel_entry,email_entry,nr_telefonu_entry,status_entry ))
    zatwierdz_btn.grid(row=14, column=0)

def zatwierdz_nowego_studenta(imie_entry,nazwisko_entry,nr_indeksu_entry,pesel_entry,email_entry,nr_telefonu_entry,status_entry):
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()

    imie = imie_entry.get()
    nazwisko = nazwisko_entry.get()
    nr_indeksu = nr_indeksu_entry.get()
    pesel = pesel_entry.get()
    email = email_entry.get()
    nr_telefonu = nr_telefonu_entry.get()
    nr_telefonu = int(nr_telefonu)
    status = status_entry.get()

    query = "INSERT INTO logowanie (login, haslo) VALUES (%s, %s)"
    cursor.execute(query, ("s" + nr_indeksu, "s" + nr_indeksu))
    mydb.commit()
    last_id_logowanie = cursor.lastrowid
    query = "INSERT INTO student (imie, nazwisko, nr_Indeksu, pesel, email, nr_telefonu, status, id_logowanie) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
    cursor.execute(query, (
    imie, nazwisko, nr_indeksu, pesel, email, nr_telefonu, status, last_id_logowanie))
    mydb.commit()
    dobre_dane_label = Label(dodaj_studenta_frame, text="Dodano nowego studenta", fg="green")
    dobre_dane_label.grid(row=100, column=0)

def wstecz_do_zarzadzaj_studentami_dodaj_studenta():
    dodaj_studenta_frame.grid_forget()
    zarzadzaj_studentami_frame.grid(row=0, column=0)

def wstecz_do_main_dziekanat_zarzadzaj_stuedntami():
    zarzadzaj_studentami_frame.grid_forget()
    dziekanat_main.grid(row=0, column=0)

def wstecz_do_zarzadzaj_stuedntami_wybierz_studenta():
    wybierz_studenta_frame.grid_forget()
    zarzadzaj_studentami_frame.grid(row=0, column=0)

def wstecz_do_wybierz_studenta_wyswietl_dane_studenta():
    wyswietl_dane_studenta_frame.grid_forget()
    wybierz_studenta_frame.grid(row=0, column=0)

def wstecz_do_wyswietl_dane_studenta():
    edytuj_dane_studenta.grid_forget()
    wyswietl_dane_studenta_frame.grid(row=0, column=0)

def wstecz_do_main_dziekanat_zarzadzaj_prowadzacymi():
    zarzadzaj_prowadzacymi_frame.grid_forget()
    dziekanat_main.grid(row=0, column=0)

def wstecz_do_zarzadzaj_prowadzacymi_dodaj_prowadzacego():
    dodaj_prowadzacego_frame.grid_forget()
    zarzadzaj_prowadzacymi_frame.grid(row=0, column=0)

def wstecz_do_zarzadzaj_prowadzacymi_wybierz_prowadzacego():
    wybierz_prowadzacego_frame.grid_forget()
    zarzadzaj_prowadzacymi_frame.grid(row=0, column=0)

def wstecz_do_wybierz_prowadzacego_wyswietl_dane_prowadzacego():
    wyswietl_dane_prowadzacego_frame.grid_forget()
    wybierz_prowadzacego_frame.grid(row=0, column=0)

def wstecz_do_wyswietl_dane_prowadzacego():
    edytuj_dane_prowadzacego.grid_forget()
    wyswietl_dane_prowadzacego_frame.grid(row=0, column=0)

def wstecz_do_main_dziekanat_zarzadzaj_kursami():
    zarzadzaj_kursami_frame.grid_forget()
    dziekanat_main.grid(row=0, column=0)

def wstecz_do_zarzadzaj_kursami_dodaj_kurs():
    dodaj_kurs_frame.grid_forget()
    zarzadzaj_kursami_frame.grid(row=0, column=0)

def edytuj_kurs(root, wybrany_kurs):
    wyswietl_kursy_frame.grid_forget()
    global edytuj_kurs_frame
    edytuj_kurs_frame = LabelFrame(root, text="EDYTUJ KURS")
    edytuj_kurs_frame.grid(row=0, column=0)
    global numer
    numer = wybrany_kurs.get()
    nazwa_btn = Button(edytuj_kurs_frame, text="Zmień nazwę", padx=30, pady=30, command=partial(zmien_nazwe_kursu, root))
    termin_btn = Button(edytuj_kurs_frame, text="Zmień termin", padx=30, pady=30, command=partial(zmien_termin_kursu, root))
    opis_btn = Button(edytuj_kurs_frame, text="Zmień opis", padx=30, pady=30, command=partial(zmien_opis_kursu, root))
    prowadzacy_btn = Button(edytuj_kurs_frame, text="Zmień prowadzącego", padx=30, pady=30, command=partial(zmien_prowadzacego_kursu, root))
    kierunek_btn = Button(edytuj_kurs_frame, text="Zmień kierunek kursu", padx=30, pady=30, command=partial(zmien_kierunek_kursu, root))
    wstecz_btn = Button(edytuj_kurs_frame, text="Wstecz",  command=wstecz_do_wyswietl_kursy_edytuj_kurs)
    nazwa_btn.grid(row=0, column=0)
    termin_btn.grid(row=1, column=0)
    opis_btn.grid(row=2, column=0)
    prowadzacy_btn.grid(row=3, column=0)
    kierunek_btn.grid(row=4, column=0)
    wstecz_btn.grid(row=10, column=3)

def zmien_kierunek_kursu(root):
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()
    edytuj_kurs_frame.grid_forget()
    global zmien_kierunek_kursu_frame
    zmien_kierunek_kursu_frame = LabelFrame(root, text="ZMIEŃ KIERUNEK DLA KURSU")
    zmien_kierunek_kursu_frame.grid(row=0, column=0)

    query = "SELECT id_kierunki, nazwa_kierunku FROM kierunki"
    cursor.execute(query)
    i = 0
    wybrany_kierunek = IntVar()
    for (id_kierunki, nazwa_kierunku) in cursor:
        nazwa_label = Label(zmien_kierunek_kursu_frame, text=nazwa_kierunku)
        nazwa_label.grid(row=i, column=0)
        separator = Label(zmien_kierunek_kursu_frame, text="                             ")
        separator.grid(row=i+1, column=0)
        Radiobutton(zmien_kierunek_kursu_frame, variable=wybrany_kierunek, value=id_kierunki).grid(row=i, column=1)
        i += 2

    wstecz_btn = Button(zmien_kierunek_kursu_frame, text="Wstecz", command=wstecz_do_edytuj_kurs_kierunek)
    wstecz_btn.grid(row=99, column=99)
    zatwierdz_btn = Button(zmien_kierunek_kursu_frame, text="Zatwierdź", command=partial(zatwierdz_edytuj_kierunek, wybrany_kierunek))
    zatwierdz_btn.grid(row=99, column=0)

def zatwierdz_edytuj_kierunek(wybrany_kierunek):
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()
    nowy_kierunek = wybrany_kierunek.get()
    query = "UPDATE kursy SET id_kierunek = %s WHERE id_kursy = %s"
    cursor.execute(query, (nowy_kierunek, numer))
    mydb.commit()
    powodzenie_label = Label(zmien_kierunek_kursu_frame, text="Zatwierdzono zmiany", fg="green")
    powodzenie_label.grid(row=100, column=0)

def zmien_prowadzacego_kursu(root):
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()
    edytuj_kurs_frame.grid_forget()
    global zmien_prowadzacego_kursu_frame
    zmien_prowadzacego_kursu_frame = LabelFrame(root, text="ZMIEŃ PROWADZĄCEGO KURSU")
    zmien_prowadzacego_kursu_frame.grid(row=0, column=0)

    query = "SELECT id_prowadzacy, imie, nazwisko FROM prowadzacy"
    cursor.execute(query)
    i = 0
    wybrany_prowadzacy = IntVar()
    for (id_prowadzacy, imie, nazwisko) in cursor:
        prowadzacy_label = Label(zmien_prowadzacego_kursu_frame, text=imie+nazwisko)
        prowadzacy_label.grid(row=i, column=0)
        separator = Label(zmien_prowadzacego_kursu_frame, text="                             ")
        separator.grid(row=i+1, column=0)
        Radiobutton(zmien_prowadzacego_kursu_frame, variable=wybrany_prowadzacy, value=id_prowadzacy).grid(row=i, column=1)
        i += 2

    wstecz_btn = Button(zmien_prowadzacego_kursu_frame, text="Wstecz", command=wstecz_do_edytuj_kurs_prowadzacy)
    wstecz_btn.grid(row=99, column=99)
    zatwierdz_btn = Button(zmien_prowadzacego_kursu_frame, text="Zatwierdź", command=partial(zatwierdz_edytuj_prowadzacego, wybrany_prowadzacy))
    zatwierdz_btn.grid(row=99, column=0)

def zatwierdz_edytuj_prowadzacego(wybrany_prowadzacy):
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()
    nowy_prowadzacy = wybrany_prowadzacy.get()
    query = "UPDATE kursy SET id_prowadzacy = %s WHERE id_kursy = %s"
    cursor.execute(query, (nowy_prowadzacy, numer))
    mydb.commit()
    powodzenie_label = Label(zmien_prowadzacego_kursu_frame, text="Zatwierdzono zmiany", fg="green")
    powodzenie_label.grid(row=100, column=0)

def zmien_opis_kursu(root):
    edytuj_kurs_frame.grid_forget()
    global zmien_opis_kursu_frame
    zmien_opis_kursu_frame = LabelFrame(root, text="ZMIEŃ OPIS KURSU")
    zmien_opis_kursu_frame.grid(row=0, column=0)
    nowy_opis_label = Label(zmien_opis_kursu_frame, text="Podaj nowy opis kursu:")
    nowy_opis_label.grid(row=0, column=0)
    nowy_opis_entry = Entry(zmien_opis_kursu_frame)
    nowy_opis_entry.grid(row=1, column=0)
    zatwierdz_btn = Button(zmien_opis_kursu_frame, text="Zatwierdź", command=partial(zatwierdz_opis_kursu, nowy_opis_entry))
    zatwierdz_btn.grid(row=2, column=0)
    wstecz_btn = Button(zmien_opis_kursu_frame, text="Wstecz",  command=wstecz_do_edytuj_kurs_opis)
    wstecz_btn.grid(row=99, column=99)

def zatwierdz_opis_kursu(nowy_opis_entry):
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()
    nowy_opis = nowy_opis_entry.get()
    query = "UPDATE kursy SET opis = %s WHERE id_kursy = %s"
    cursor.execute(query, (nowy_opis, numer))
    mydb.commit()
    powodzenie_label = Label(zmien_opis_kursu_frame, text="Zatwierdzono zmiany", fg="green")
    powodzenie_label.grid(row=100, column=0)

def zmien_termin_kursu(root):
    edytuj_kurs_frame.grid_forget()
    global zmien_termin_kursu_frame
    zmien_termin_kursu_frame = LabelFrame(root, text="ZMIEŃ TERMIN KURSU")
    zmien_termin_kursu_frame.grid(row=0, column=0)
    nowy_termin_label = Label(zmien_termin_kursu_frame, text="Podaj nowy termin kursu:")
    nowy_termin_label.grid(row=0, column=0)
    nowy_termin_entry = Entry(zmien_termin_kursu_frame)
    nowy_termin_entry.grid(row=1, column=0)
    zatwierdz_btn = Button(zmien_termin_kursu_frame, text="Zatwierdź", command=partial(zatwierdz_termin_kursu, nowy_termin_entry))
    zatwierdz_btn.grid(row=2, column=0)
    wstecz_btn = Button(zmien_termin_kursu_frame, text="Wstecz",  command=wstecz_do_edytuj_kurs_termin)
    wstecz_btn.grid(row=99, column=99)

def zatwierdz_termin_kursu(nowy_termin_entry):
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()
    nowy_termin = nowy_termin_entry.get()
    query = "UPDATE kursy SET termin = %s WHERE id_kursy = %s"
    cursor.execute(query, (nowy_termin, numer))
    mydb.commit()
    powodzenie_label = Label(zmien_termin_kursu_frame, text="Zatwierdzono zmiany", fg="green")
    powodzenie_label.grid(row=100, column=0)

def zmien_nazwe_kursu(root):
    edytuj_kurs_frame.grid_forget()
    global zmien_nazwe_kursu_frame
    zmien_nazwe_kursu_frame = LabelFrame(root, text="ZMIEŃ NAZWĘ KURSU")
    zmien_nazwe_kursu_frame.grid(row=0, column=0)
    nowa_nazwa_label = Label(zmien_nazwe_kursu_frame, text="Podaj nową nazwę kursu:")
    nowa_nazwa_label.grid(row=0, column=0)
    nowa_nazwa_entry = Entry(zmien_nazwe_kursu_frame)
    nowa_nazwa_entry.grid(row=1, column=0)
    zatwierdz_btn = Button(zmien_nazwe_kursu_frame, text="Zatwierdź", command=partial(zatwierdz_nazwe_kursu, nowa_nazwa_entry))
    zatwierdz_btn.grid(row=2, column=0)
    wstecz_btn = Button(zmien_nazwe_kursu_frame, text="Wstecz",  command=wstecz_do_edytuj_kurs_haslo)
    wstecz_btn.grid(row=99, column=99)

def zatwierdz_nazwe_kursu(nowa_nazwa_entry):
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()
    nowa_nazwa = nowa_nazwa_entry.get()
    query = "UPDATE kursy SET nazwa_kursu = %s WHERE id_kursy = %s"
    cursor.execute(query, (nowa_nazwa, numer))
    mydb.commit()
    powodzenie_label = Label(zmien_nazwe_kursu_frame, text="Zatwierdzono zmiany", fg="green")
    powodzenie_label.grid(row=100, column=0)

def zarzadzaj_kierunekami(root):
    dziekanat_main.grid_forget()
    global zarzadzaj_kierunkami_frame
    zarzadzaj_kierunkami_frame = LabelFrame(root, text="ZARZĄDZAJ KIERUNKAMI")
    zarzadzaj_kierunkami_frame.grid(row=0, column=0)

    dodaj_kurs_btn = Button(zarzadzaj_kierunkami_frame, text="Dodaj kierunek", padx=30, pady=30, command=partial(dodaj_kierunek, root))
    wyswietl_kurs = Button(zarzadzaj_kierunkami_frame, text="Wyświetl kierunek", padx=30, pady=30, command=partial(wyswietl_kierunki, root))
    dodaj_kurs_btn.grid(row=0, column=0)
    wyswietl_kurs.grid(row=0, column=1)
    wstecz_btn = Button(zarzadzaj_kierunkami_frame, text="Wstecz", command=wstecz_do_main_dziekanat_zarzadzaj_kierunkami)
    wstecz_btn.grid(row=2, column=2)

def wyswietl_kierunki(root):
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()
    zarzadzaj_kierunkami_frame.grid_forget()
    global wyswietl_kierunki_frame
    wyswietl_kierunki_frame = LabelFrame(root, text="ZARZĄDZAJ KIERUNKAMI  ")
    wyswietl_kierunki_frame.grid(row=0, column=0)

    query = "SELECT * FROM kierunki"
    cursor.execute(query)
    i = 0
    wybrany_kierunek = IntVar()
    for (id_kierunki, nazwa_kierunku, opis) in cursor:
        nazwa_label = Label(wyswietl_kierunki_frame, text=nazwa_kierunku)
        opis_label = Label(wyswietl_kierunki_frame, text=opis, wraplength=400)
        separator = Label(wyswietl_kierunki_frame, text="                 ")
        nazwa_label.grid(row=i, column=0)
        opis_label.grid(row=i+1, column=0)
        separator.grid(row=i+2, column=0)
        Radiobutton(wyswietl_kierunki_frame, variable=wybrany_kierunek, value=id_kierunki).grid(row=i, column=1)
        i += 3

    wstecz_btn = Button(wyswietl_kierunki_frame, text="Wstecz", command=wstecz_do_zarzadzaj_kierunkami_wyswietl_kierunki)
    wstecz_btn.grid(row=99, column=99)
    usun_btn = Button(wyswietl_kierunki_frame, text="Usuń kierunek", command=partial(usun_kierunek, wybrany_kierunek))
    usun_btn.grid(row=99, column=0)
    edytuj_btn = Button(wyswietl_kierunki_frame, text="Edytuj kierunek", command=partial(edytuj_kierunek, root, wybrany_kierunek))
    edytuj_btn.grid(row=99, column=1)

def usun_kierunek(wybrany_kierunek):
    global kierunek
    kierunek = wybrany_kierunek.get()
    usun_potwierdz_btn = Button(wyswietl_kierunki_frame, text="Potwierdź usunięcie kierunku", command=partial(usun_potwierdz_kierunek))
    usun_potwierdz_btn.grid(row=99, column=0)

def edytuj_kierunek(root, wybrany_kierunek):
    global kierunek
    kierunek = wybrany_kierunek.get()
    wyswietl_kierunki_frame.grid_forget()
    global edytuj_kierunek_frame
    edytuj_kierunek_frame = LabelFrame(root, text="EDYTUJ KIERUNEK")
    edytuj_kierunek_frame.grid(row=0, column=0)

    nazwa_btn = Button(edytuj_kierunek_frame, text="Edytuj nazwę kierunku", padx=30, pady=30, command=partial(edytuj_nazwe_kierunku, root))
    opis_btn = Button(edytuj_kierunek_frame, text="Edytuj opis kierunku", padx=30, pady=30, command=partial(edytuj_opis_kierunku, root))
    nazwa_btn.grid(row=0, column=0)
    opis_btn.grid(row=1, column=0)
    wstecz_btn = Button(edytuj_kierunek_frame, text="Wstecz", command=wstecz_do_wyswietl_kierunki_edytuj_kierunek)
    wstecz_btn.grid(row=2, column=1)

def edytuj_opis_kierunku(root):
    edytuj_kierunek_frame.grid_forget()
    global edytuj_opis_kierunku_frame
    edytuj_opis_kierunku_frame = LabelFrame(root, text="EDYTUJ OPIS KIERUNKU")
    edytuj_opis_kierunku_frame.grid(row=0, column=0)

    nowy_opis_label = Label(edytuj_opis_kierunku_frame, text="Podaj nowy opis kierunku:")
    nowy_opis_label.grid(row=0, column=0)
    nowy_opis_entry = Entry(edytuj_opis_kierunku_frame)
    nowy_opis_entry.grid(row=1, column=0)
    zatwierdz_btn = Button(edytuj_opis_kierunku_frame, text="Zatwierdź", command=partial(zatwierdz_opis_kierunku, nowy_opis_entry))
    zatwierdz_btn.grid(row=2, column=0)
    wstecz_btn = Button(edytuj_opis_kierunku_frame, text="Wstecz",  command=wstecz_do_edytuj_kierunki_opis)
    wstecz_btn.grid(row=99, column=99)

def zatwierdz_opis_kierunku(nowy_opis_entry):
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()
    nowy_opis = nowy_opis_entry.get()
    query = "UPDATE kierunki SET opis = %s WHERE id_kierunki = %s"
    cursor.execute(query, (nowy_opis, kierunek))
    mydb.commit()
    powodzenie_label = Label(edytuj_opis_kierunku_frame, text="Zatwierdzono zmiany", fg="green")
    powodzenie_label.grid(row=100, column=0)

def edytuj_nazwe_kierunku(root):
    edytuj_kierunek_frame.grid_forget()
    global edytuj_nazwe_kierunku_frame
    edytuj_nazwe_kierunku_frame = LabelFrame(root, text="EDYTUJ NAZWĘ KIERUNKU")
    edytuj_nazwe_kierunku_frame.grid(row=0, column=0)

    nowa_nazwa_label = Label(edytuj_nazwe_kierunku_frame, text="Podaj nową nazwę kierunku:")
    nowa_nazwa_label.grid(row=0, column=0)
    nowa_nazwa_entry = Entry(edytuj_nazwe_kierunku_frame)
    nowa_nazwa_entry.grid(row=1, column=0)
    zatwierdz_btn = Button(edytuj_nazwe_kierunku_frame, text="Zatwierdź", command=partial(zatwierdz_nazwe_kierunku, nowa_nazwa_entry))
    zatwierdz_btn.grid(row=2, column=0)
    wstecz_btn = Button(edytuj_nazwe_kierunku_frame, text="Wstecz",  command=wstecz_do_edytuj_kierunki_nazwa)
    wstecz_btn.grid(row=99, column=99)

def zatwierdz_nazwe_kierunku(nowa_nazwa_entry):
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()
    nowa_nazwa = nowa_nazwa_entry.get()
    query = "UPDATE kierunki SET nazwa_kierunku = %s WHERE id_kierunki = %s"
    cursor.execute(query, (nowa_nazwa, kierunek))
    mydb.commit()
    powodzenie_label = Label(edytuj_nazwe_kierunku_frame, text="Zatwierdzono zmiany", fg="green")
    powodzenie_label.grid(row=100, column=0)

def usun_potwierdz_kierunek():
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()
    query = "DELETE FROM zapisany_na_kierunek WHERE id_kierunek = %s"
    cursor.execute(query, (kierunek,))
    mydb.commit()
    query = "DELETE FROM kierunki WHERE id_kierunki = %s"
    cursor.execute(query, (kierunek,))
    mydb.commit()
    powodzenie_label = Label(wyswietl_kierunki_frame, text="Zatwierdzono zmiany", fg="green")
    powodzenie_label.grid(row=100, column=0)

def dodaj_kierunek(root):
    zarzadzaj_kierunkami_frame.grid_forget()
    global dodaj_kierunek_frame
    dodaj_kierunek_frame = LabelFrame(root, text="DODAJ KIERUNEK")
    dodaj_kierunek_frame.grid(row=0, column=0)

    nazwa_label = Label(dodaj_kierunek_frame, text="Nazwa: ")
    opis_label = Label(dodaj_kierunek_frame, text="Opis: ")
    global nazwa_entry
    nazwa_entry = Entry(dodaj_kierunek_frame)
    global opis_entry
    opis_entry = Entry(dodaj_kierunek_frame, width=50)
    nazwa_label.grid(row=0, column=0)
    opis_label.grid(row=2, column=0)
    nazwa_entry.grid(row=1, column=0)
    opis_entry.grid(row=3, column=0, ipady=30)

    wstecz_btn = Button(dodaj_kierunek_frame, text="Wstecz", command=wstecz_do_zarzadzaj_kierunkami_dodaj_kierunek)
    wstecz_btn.grid(row=5, column=3)
    zatwierdz_nowy_kurs = Button(dodaj_kierunek_frame, text="Zatwierdź", command=partial(zatwierdz_nowy_kierunek, root, nazwa_entry, opis_entry))
    zatwierdz_nowy_kurs.grid(row=4, column=0)

def zatwierdz_nowy_kierunek(root, nazwa_entry, opis_entry):
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()
    nazwa = nazwa_entry.get()
    opis = opis_entry.get()
    query = "INSERT INTO kierunki (nazwa_kierunku, opis) VALUES (%s, %s)"
    cursor.execute(query, (nazwa, opis))
    mydb.commit()
    powodzenie_label = Label(dodaj_kierunek_frame, text="Dodano kierunek", fg="green")
    powodzenie_label.grid(row=100, column=0)

def wstecz_do_dodaj_kurs_kierunek():
    kierunek_dodaj_kurs_frame.grid_forget()
    dodaj_kurs_frame.grid(row=0, column=0)

def wstecz_do_dodaj_kurs_prowadzacy():
    prowadzacy_dodaj_kurs_frame.grid_forget()
    kierunek_dodaj_kurs_frame.grid(row=0, column=0)

def wstecz_do_zarzadzaj_kursami_wyswietl_kursy():
    wyswietl_kursy_frame.grid_forget()
    zarzadzaj_kursami_frame.grid(row=0, column=0)

def wstecz_do_wyswietl_kursy_edytuj_kurs():
    edytuj_kurs_frame.grid_forget()
    wyswietl_kursy_frame.grid(row=0, column=0)

def wstecz_do_edytuj_kurs_haslo():
    zmien_nazwe_kursu_frame.grid_forget()
    edytuj_kurs_frame.grid(row=0, column=0)

def wstecz_do_edytuj_kurs_termin():
    zmien_termin_kursu_frame.grid_forget()
    edytuj_kurs_frame.grid(row=0, column=0)

def wstecz_do_edytuj_kurs_opis():
    zmien_opis_kursu_frame.grid_forget()
    edytuj_kurs_frame.grid(row=0, column=0)

def wstecz_do_edytuj_kurs_prowadzacy():
    zmien_prowadzacego_kursu_frame.grid_forget()
    edytuj_kurs_frame.grid(row=0, column=0)

def wstecz_do_edytuj_kurs_kierunek():
    zmien_kierunek_kursu_frame.grid_forget()
    edytuj_kurs_frame.grid(row=0, column=0)

def wstecz_do_main_dziekanat_zarzadzaj_kierunkami():
    zarzadzaj_kierunkami_frame.grid_forget()
    dziekanat_main.grid(row=0, column=0)

def wstecz_do_zarzadzaj_kierunkami_dodaj_kierunek():
    dodaj_kierunek_frame.grid_forget()
    zarzadzaj_kierunkami_frame.grid(row=0, column=0)

def wstecz_do_zarzadzaj_kierunkami_wyswietl_kierunki():
    wyswietl_kierunki_frame.grid_forget()
    zarzadzaj_kierunkami_frame.grid(row=0, column=0)

def wstecz_do_wyswietl_kierunki_edytuj_kierunek():
    edytuj_kierunek_frame.grid_forget()
    wyswietl_kierunki_frame.grid(row=0, column=0)

def wstecz_do_edytuj_kierunki_nazwa():
    edytuj_nazwe_kierunku_frame.grid_forget()
    edytuj_kierunek_frame.grid(row=0, column=0)

def wstecz_do_edytuj_kierunki_opis():
    edytuj_opis_kierunku_frame.grid_forget()
    edytuj_kierunek_frame.grid(row=0, column=0)

def wstecz_do_dziekanat_main_haslo():
    zmien_haslo_frame.grid_forget()
    dziekanat_main.grid(row=0, column=0)