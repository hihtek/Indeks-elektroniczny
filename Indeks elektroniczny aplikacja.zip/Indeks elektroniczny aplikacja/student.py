import mysql.connector
from tkinter import *
from functools import partial


def student_main(id_zalogowano,logowanie_pasy, root):
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()
    query = "SELECT id_student FROM student WHERE id_logowanie = %s"
    cursor.execute(query, (id_zalogowano))
    for id_student in cursor:
        pass

    logowanie_pasy.grid_forget()
    global student_main
    student_main = LabelFrame(root, text="STUDENT MAIN")
    student_main.grid(row=0, column=0)

    # BUTTONY
    wybor_wyswietl_dane = Button(student_main, text="1. WYŚWIETL DANE", padx=30, pady=30, command=partial(wyswietl_dane,id_zalogowano, root, student_main))
    wybor_wyswietl_dane.grid(row=0, column=0)
    wybor_wyswietl_kursy = Button(student_main, text="2. WYŚWIETL KURSY", padx=30, pady=30, command=partial(wyswietl_kursy, root, id_student))
    wybor_wyswietl_kursy.grid(row=0, column=1)
    wybor_wyswietl_oceny = Button(student_main, text="3. WYŚWIETL OCENY", padx=30, pady=30, command=partial(wyswietl_oceny, root, id_student))
    wybor_wyswietl_oceny.grid(row=1, column=0)
    wybor_zmien_haslo = Button(student_main, text="4. ZMIEŃ HASŁO", padx=30, pady=30, command=partial(zmien_haslo, id_zalogowano, root, id_student))
    wybor_zmien_haslo.grid(row=1, column=1)
    wologuj_btn = Button(student_main, text="Wyloguj", command=wyloguj)
    wologuj_btn.grid(row=2, column=3)

def wyloguj():
    sys.exit()


def wstecz_do_student_main_dane():
    dane_student_frame.grid_forget()
    student_main.grid(row=0, column=0)

def wstecz_do_student_main_kursy():
    kursy_student_frame.grid_forget()
    student_main.grid(row=0, column=0)

def wstecz_do_student_main_oceny():
    ocany_student_frame.grid_forget()
    student_main.grid(row=0, column=0)

def wstecz_do_student_main_haslo():
    zmien_haslo_frame.grid_forget()
    student_main.grid(row=0, column=0)

def wyswietl_dane(id_zalogowany, root, student_main):
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()

    student_main.grid_forget()
    global dane_student_frame
    dane_student_frame = LabelFrame(root, text="DANE STUDENTA")
    dane_student_frame.grid(row=0, column=0)

    query = "SELECT id_student, imie, nazwisko, nr_Indeksu, pesel, email, nr_telefonu, status FROM student WHERE id_logowanie = %s"
    cursor.execute(query, (id_zalogowany))
    for (id_student, imie, nazwisko, nr_indeksu, pesel, email, nr_telefonu, status) in cursor:
        pass
    # Z zapisany_na_kierunki semestr i stopień studiów
    query = "SELECT semestr, stopien_studiow, id_kierunek FROM zapisany_na_kierunek WHERE id_student = %s"
    cursor.execute(query, (id_student,))
    for (semestr, stopien_studiow, id_kierunek) in cursor:
        pass
    # Z kierunków nazwa studiów
    query = "SELECT nazwa_kierunku FROM kierunki WHERE id_kierunki = %s"
    cursor.execute(query, (id_kierunek,))
    for id_kierunek in cursor:
        pass

    imie_label = Label(dane_student_frame, text="Imię: "+imie)
    nazwisko_label = Label(dane_student_frame, text="Nazwisko: " +nazwisko)
    nr_indeksu_label = Label(dane_student_frame, text="Nr indeksu: " +nr_indeksu)
    pesel_label = Label(dane_student_frame, text="Pesel: " +pesel)
    email_label = Label(dane_student_frame, text="Adres e-mail: " +email)
    nr_telefonu_label = Label(dane_student_frame, text="Numer telefonu: " +str(nr_telefonu))
    status_label= Label(dane_student_frame, text="Status studenta: " +status)
    semestr_label = Label(dane_student_frame, text="Semestr: " +str(semestr))
    stopien_studiow_label = Label(dane_student_frame, text="Stopień studiów: " +stopien_studiow)
    nazwa_kierunku_label = Label(dane_student_frame, text="Nazwa kierunku: " +id_kierunek[0])

    wstecz_do_student_main = Button(dane_student_frame, text="Wstecz", command=wstecz_do_student_main_dane)
    wstecz_do_student_main.grid(row=99, column=99)

    imie_label.grid(row=0, column=1)
    nazwisko_label.grid(row=1, column=1)
    nr_indeksu_label.grid(row=2, column=1)
    pesel_label.grid(row=3, column=1)
    email_label.grid(row=4, column=1)
    nr_telefonu_label.grid(row=5, column=1)
    status_label.grid(row=6, column=1)
    semestr_label.grid(row=7, column=1)
    stopien_studiow_label.grid(row=8, column=1)
    nazwa_kierunku_label.grid(row=9, column=1)

def wyswietl_kursy(root, id_student):
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()

    student_main.grid_forget()
    global kursy_student_frame
    kursy_student_frame = LabelFrame(root, text="KURSY STUDENTA")
    kursy_student_frame.grid(row=0, column=0)

    query = "SELECT zapisany_na_kurs.id_kursu, kursy.nazwa_kursu, kursy.termin FROM zapisany_na_kurs, kursy WHERE id_student = %s AND zapisany_na_kurs.id_kursu = kursy.id_kursy"
    cursor.execute(query, (id_student))

    i = 0
    for (id_kursu, nazwa_kursu, termin) in cursor:
        nazwa_kursu_label = Label(kursy_student_frame, text="Nazwa kursu: " + nazwa_kursu)
        termin_label = Label(kursy_student_frame, text="Termin: " + termin)
        separator = Label(kursy_student_frame, text="                              ")
        nazwa_kursu_label.grid(row=i, column=0)
        termin_label.grid(row=i+1, column=0)
        separator.grid(row=i+2, column=0)
        i += 3

    wstecz_do_student_main = Button(kursy_student_frame, text="Wstecz", command=wstecz_do_student_main_kursy)
    wstecz_do_student_main.grid(row=99, column=99)

def wyswietl_oceny(root, id_student):
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()  # cursor - taki wskaźnik/uchwyt do poruszania się po bazie
    query = "SELECT zapisany_na_kurs.id_zapisany_na_kurs, zapisany_na_kurs.id_kursu, oceny.ocena, oceny.opis, kursy.nazwa_kursu FROM zapisany_na_kurs, oceny, kursy WHERE oceny.id_zapisany_na_kurs = zapisany_na_kurs.id_zapisany_na_kurs AND zapisany_na_kurs.id_student = %s AND zapisany_na_kurs.id_kursu = kursy.id_kursy"
    cursor.execute(query, (id_student))

    student_main.grid_forget()
    global ocany_student_frame
    ocany_student_frame = LabelFrame(root, text="KURSY STUDENTA")
    ocany_student_frame.grid(row=0, column=0)

    i = 0
    for (id_zapisany_na_kurs, id_kursu, ocena, opis, nazwa_kursu) in cursor:
        nazwa_kursu_label = Label(ocany_student_frame, text="Nazwa kursu: " + nazwa_kursu)
        ocena_label = Label(ocany_student_frame, text="Ocena: " + str(ocena))
        opis_label = Label(ocany_student_frame, text="Opis: " + str(opis))
        separator = Label(ocany_student_frame, text="                              ")

        nazwa_kursu_label.grid(row=i, column=0)
        ocena_label.grid(row=i + 1, column=0)
        opis_label.grid(row=i + 2, column=0)
        separator.grid(row=i + 3, column=0)
        i += 4

    wstecz_do_student_main = Button(ocany_student_frame, text="Wstecz", command=wstecz_do_student_main_oceny)
    wstecz_do_student_main.grid(row=99, column=99)

def zmien_haslo(id_zalogowany, root, id_student):
    student_main.grid_forget()
    global zmien_haslo_frame
    zmien_haslo_frame = LabelFrame(root, text="ZMIEŃ HASŁO")
    zmien_haslo_frame.grid(row=0, column=0)


    stare_haslo_label = Label(zmien_haslo_frame, text="Stare hasło: ")
    nowe_haslo_label = Label(zmien_haslo_frame, text="Nowe hasło: ")
    potwierdz_haslo_label = Label(zmien_haslo_frame, text="Potwierdź hasło: ")

    global stare_haslo_entry
    stare_haslo_entry = Entry(zmien_haslo_frame, width=40)
    global nowe_haslo_entry
    nowe_haslo_entry = Entry(zmien_haslo_frame, width=40)
    global potwierdz_haslo_entry
    potwierdz_haslo_entry = Entry(zmien_haslo_frame, width=40)
    zatwierdz_btn = Button(zmien_haslo_frame, text="Zatwierdź", command=partial(zatwierdz_zmiane_hasla, id_zalogowany))
    wstecz_btn = Button(zmien_haslo_frame, text="Wstecz", command=wstecz_do_student_main_haslo)

    stare_haslo_label.grid(row=0, column=0)
    nowe_haslo_label.grid(row=1, column=0)
    potwierdz_haslo_label.grid(row=2, column=0)
    stare_haslo_entry.grid(row=0, column=1)
    nowe_haslo_entry.grid(row=1, column=1)
    potwierdz_haslo_entry.grid(row=2, column=1)
    zatwierdz_btn.grid(row=3, column=1)
    wstecz_btn.grid(row=3, column=2)


def zatwierdz_zmiane_hasla(id_zalogowany):

    wprowadzone_haslo = stare_haslo_entry.get()
    nowe_haslo = nowe_haslo_entry.get()
    potwierdz_nowe_haslo = potwierdz_haslo_entry.get()

    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()  # cursor - taki wskaźnik/uchwyt do poruszania się po bazie

    query = "SELECT haslo FROM logowanie WHERE id_logowanie = %s"
    cursor.execute(query, (id_zalogowany))

    for haslo in cursor:
        obecne_haslo = haslo[0]

    if (obecne_haslo == wprowadzone_haslo) and (nowe_haslo == potwierdz_nowe_haslo):
        query = "UPDATE logowanie SET haslo = %s WHERE id_logowanie = %s"
        cursor.execute(query, (nowe_haslo, id_zalogowany[0]))
        mydb.commit()
        dobre_dane_label = Label(zmien_haslo_frame, text="Hasło zaktualizowane poprawnie", fg="green")
        dobre_dane_label.grid(row=4, column=1)
    else:
        zle_dane_label = Label(zmien_haslo_frame, text="Podano złe dane", fg="red")
        zle_dane_label.grid(row=4, column=1)
