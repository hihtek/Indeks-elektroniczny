import mysql.connector
import sys
from tkinter import *
from functools import partial


def prowadzacy_main(id_zalogowany,logowanie_pasy, root):
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()
    query = "SELECT id_prowadzacy FROM prowadzacy WHERE id_logowanie = %s"
    cursor.execute(query, (id_zalogowany))
    for id_prowadzacy in cursor:
        pass

    logowanie_pasy.grid_forget()
    global prowadzacy_main
    prowadzacy_main = LabelFrame(root, text="PROWADZĄCY MAIN")
    prowadzacy_main.grid(row=0, column=0)

    wybor_wyswietl_dane = Button(prowadzacy_main, text="1. WYŚWIETL DANE", padx=30, pady=30, command=partial(wyswietl_dane, id_zalogowany, root,))
    wybor_wyswietl_dane.grid(row=0, column=0)
    wybor_wyswietl_kursy = Button(prowadzacy_main, text="2. WYŚWIETL SWOJE KURSY", padx=30, pady=30, command=partial(wyswietl_kursy, id_prowadzacy, root,))
    wybor_wyswietl_kursy.grid(row=0, column=1)
    wybor_wyswietl_oceny = Button(prowadzacy_main, text="3. ZMIEŃ HASŁO", padx=30, pady=30, command=partial(zmien_haslo, id_zalogowany, root, id_prowadzacy))
    wybor_wyswietl_oceny.grid(row=0, column=2)
    wologuj_btn = Button(prowadzacy_main, text="Wyloguj", command=wyloguj)
    wologuj_btn.grid(row=2, column=1)


def zmien_haslo(id_zalogowany, root, id_prowadzacy):
    prowadzacy_main.grid_forget()
    global zmien_haslo_frame
    zmien_haslo_frame = LabelFrame(root, text="ZMIEŃ HASŁO")
    zmien_haslo_frame.grid(row=0, column=0)

    stare_haslo_label = Label(zmien_haslo_frame, text="Stare hasło: ")
    nowe_haslo_label = Label(zmien_haslo_frame, text="Nowe hasło: ")
    potwierdz_haslo_label = Label(zmien_haslo_frame, text="Potwierdź hasło: ")

    global stare_haslo_entry
    stare_haslo_entry = Entry(zmien_haslo_frame, width=40)
    global nowe_haslo_entry
    nowe_haslo_entry = Entry(zmien_haslo_frame, width=40)
    global potwierdz_haslo_entry
    potwierdz_haslo_entry = Entry(zmien_haslo_frame, width=40)
    zatwierdz_btn = Button(zmien_haslo_frame, text="Zatwierdź", command=partial(zatwierdz_zmiane_hasla, id_zalogowany))
    wstecz_btn = Button(zmien_haslo_frame, text="Wstecz", command=wstecz_do_prowadzacy_main_haslo)

    stare_haslo_label.grid(row=0, column=0)
    nowe_haslo_label.grid(row=1, column=0)
    potwierdz_haslo_label.grid(row=2, column=0)
    stare_haslo_entry.grid(row=0, column=1)
    nowe_haslo_entry.grid(row=1, column=1)
    potwierdz_haslo_entry.grid(row=2, column=1)
    zatwierdz_btn.grid(row=3, column=1)
    wstecz_btn.grid(row=3, column=2)

def zatwierdz_zmiane_hasla(id_zalogowany):

    wprowadzone_haslo = stare_haslo_entry.get()
    nowe_haslo = nowe_haslo_entry.get()
    potwierdz_nowe_haslo = potwierdz_haslo_entry.get()

    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()  # cursor - taki wskaźnik/uchwyt do poruszania się po bazie

    query = "SELECT haslo FROM logowanie WHERE id_logowanie = %s"
    cursor.execute(query, (id_zalogowany))

    for haslo in cursor:
        obecne_haslo = haslo[0]

    if (obecne_haslo == wprowadzone_haslo) and (nowe_haslo == potwierdz_nowe_haslo):
        query = "UPDATE logowanie SET haslo = %s WHERE id_logowanie = %s"
        cursor.execute(query, (nowe_haslo, id_zalogowany[0]))
        mydb.commit()
        dobre_dane_label = Label(zmien_haslo_frame, text="Hasło zaktualizowane poprawnie", fg="green")
        dobre_dane_label.grid(row=4, column=1)
    else:
        zle_dane_label = Label(zmien_haslo_frame, text="Podano złe dane", fg="red")
        zle_dane_label.grid(row=4, column=1)

def wyswietl_dane(id_zalogowany, root):
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()

    prowadzacy_main.grid_forget()
    global dane_prowadzacy_frame
    dane_prowadzacy_frame = LabelFrame(root, text="DANE STUDENTA")
    dane_prowadzacy_frame.grid(row=0, column=0)

    query = "SELECT imie, nazwisko, pesel, email FROM prowadzacy WHERE id_logowanie = %s"
    cursor.execute(query, (id_zalogowany))
    for (imie, nazwisko, pesel, email) in cursor:
        pass

    imie_label = Label(dane_prowadzacy_frame, text="Imię: "+imie)
    nazwisko_label = Label(dane_prowadzacy_frame, text="Nazwisko: " +nazwisko)
    pesel_label = Label(dane_prowadzacy_frame, text="Pesel: " +pesel)
    email_label = Label(dane_prowadzacy_frame, text="Adres e-mail: " +email)

    wstecz_do_student_main = Button(dane_prowadzacy_frame, text="Wstecz", command=wstecz_do_prowadzacy_main_dane)
    wstecz_do_student_main.grid(row=99, column=99)

    imie_label.grid(row=0, column=1)
    nazwisko_label.grid(row=1, column=1)
    pesel_label.grid(row=3, column=1)
    email_label.grid(row=4, column=1)

def wyswietl_kursy(id_prowadzacy, root):
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()

    prowadzacy_main.grid_forget()
    global kursy_prowadzacy_frame
    kursy_prowadzacy_frame = LabelFrame(root, text="PROWADZONE KURSY")
    kursy_prowadzacy_frame.grid(row=0, column=0)

    query = "SELECT kursy.id_kursy, kursy.nazwa_kursu, kursy.termin, kursy.id_kierunek, kierunki.nazwa_kierunku FROM kursy, kierunki WHERE id_prowadzacy = %s AND kursy.id_kierunek = kierunki.id_kierunki"
    cursor.execute(query, (id_prowadzacy))

    wybrane_id_kursy = IntVar()
    i = 0

    for (id_kursy, nazwa_kursu, termin, id_kierunek, nazwa_kierunku) in cursor:

        nazwa_kursu_label = Label(kursy_prowadzacy_frame, text="Nazwa kursu: " + nazwa_kursu)
        termin_label = Label(kursy_prowadzacy_frame, text="Termin: " + termin)
        nazwa_kierunku_label = Label(kursy_prowadzacy_frame, text="Nazwa kierunku: " + nazwa_kierunku)
        separator=Label(kursy_prowadzacy_frame, text="                             " )

        Radiobutton(kursy_prowadzacy_frame, variable=wybrane_id_kursy, value=id_kursy).grid(row=i, column=1)

        nazwa_kursu_label.grid(row=i, column=0)
        termin_label.grid(row=i+1, column=0)
        nazwa_kierunku_label.grid(row=i+2, column=0)
        separator.grid(row=i+3, column=0)
        i += 4



    wstecz_btn = Button(kursy_prowadzacy_frame, text="Wstecz", command=wstecz_do_prowadzacy_main_kursy)
    wstecz_btn.grid(row=99, column=99)
    wstaw_oceny_btn = Button(kursy_prowadzacy_frame, text="Wstaw oceny", command=partial(wybierz_studenta, wybrane_id_kursy, root))
    wstaw_oceny_btn.grid(row=99, column=98)

def wybierz_studenta(wybrane_id_kursy, root):

    kurs = wybrane_id_kursy.get()
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()
    kursy_prowadzacy_frame.grid_forget()
    global oceny_wybierz_studenta_frame
    oceny_wybierz_studenta_frame = LabelFrame(root, text="WYBIERZ STUDENTA")
    oceny_wybierz_studenta_frame.grid(row=0, column=0)

    query = "SELECT zapisany_na_kurs.id_zapisany_na_kurs, zapisany_na_kurs.id_student, student.imie, student.nazwisko FROM zapisany_na_kurs, student WHERE id_kursu = %s AND zapisany_na_kurs.id_student = student.id_student"
    cursor.execute(query,(kurs,))
    i = 0
    wybrany_student = IntVar()

    for (id_zapisany_na_kurs, id_student, imie, nazwisko) in cursor:
        imie_label = Label(oceny_wybierz_studenta_frame, text=imie)
        nazwisko_label = Label(oceny_wybierz_studenta_frame, text=nazwisko)
        separator=Label(oceny_wybierz_studenta_frame, text="                             " )
        Radiobutton(oceny_wybierz_studenta_frame, variable=wybrany_student, value=id_student).grid(row=i, column=2)

        imie_label.grid(row=i, column=0)
        nazwisko_label.grid(row=i, column=1)
        separator.grid(row=i+2, column=0)
        i += 3

    wybierz_studenta_btn = Button(oceny_wybierz_studenta_frame, text="Wybierz studenta", command=partial(wstaw_oceny, wybrany_student, kurs, root))
    wstecz_do_wyswietl_kursy_btn = Button(oceny_wybierz_studenta_frame, text="Wstecz", command=wstecz_do_wyswietl_kursy)
    wybierz_studenta_btn.grid(row=99, column=98)
    wstecz_do_wyswietl_kursy_btn.grid(row=99, column=99)

def wstaw_oceny(wybrany_student, kurs, root):
    student = wybrany_student.get()

    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()

    oceny_wybierz_studenta_frame.grid_forget()
    global oceny_prowadzacy_frame
    oceny_prowadzacy_frame = LabelFrame(root, text="WSTAW OCENĘ")
    oceny_prowadzacy_frame.grid(row=0, column=0)


    ocena_label = Label(oceny_prowadzacy_frame, text="Ocena: ")
    opis_label = Label(oceny_prowadzacy_frame, text="Opis: ")
    ocena_entry = Entry(oceny_prowadzacy_frame, width=5)
    opis_entry = Entry(oceny_prowadzacy_frame, width=30)
    ocena_label.grid(row=0, column=0)
    ocena_entry.grid(row=1, column=0)
    opis_label.grid(row=2, column=0)
    opis_entry.grid(row=3, column=0)

    query = "SELECT id_zapisany_na_kurs FROM zapisany_na_kurs WHERE id_student = %s AND id_kursu = %s"
    cursor.execute(query, (student, kurs,))
    for (id) in cursor:
        pass

    zatwierdz_btn = Button(oceny_prowadzacy_frame, text="Zatwierdź", command=partial(zatwierdz_ocene, ocena_entry, opis_entry, id))
    zatwierdz_btn.grid(row=99, column=0)
    wstecz_do_oceny_wybierz_studenta_btn = Button(oceny_prowadzacy_frame, text="Wstecz", command=wstecz_do_oceny_wybierz_studenta)
    wstecz_do_oceny_wybierz_studenta_btn.grid(row=99, column=1)

def zatwierdz_ocene(ocena_entry, opis_entry, id):
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="indeks_elektroniczny")
    cursor = mydb.cursor()
    ocena = ocena_entry.get()
    opis = opis_entry.get()
    query = "INSERT INTO oceny (ocena, opis, id_zapisany_na_kurs) VALUES (%s, %s, %s)"
    cursor.execute(query, (ocena, opis, id[0]))
    mydb.commit()
    powodzenie_label = Label(oceny_prowadzacy_frame, text="Zatwierdzono zmiany", fg="green")
    powodzenie_label.grid(row=100, column=0)

def wyloguj():
    sys.exit()

def wstecz_do_prowadzacy_main_kursy():
    kursy_prowadzacy_frame.grid_forget()
    prowadzacy_main.grid(row=0, column=0)

def wstecz_do_prowadzacy_main_dane():
    dane_prowadzacy_frame.grid_forget()
    prowadzacy_main.grid(row=0, column=0)

def wstecz_do_wyswietl_kursy():
    oceny_wybierz_studenta_frame.grid_forget()
    kursy_prowadzacy_frame.grid(row=0, column=0)

def wstecz_do_oceny_wybierz_studenta():
    oceny_prowadzacy_frame.grid_forget()
    oceny_wybierz_studenta_frame.grid(row=0, column=0)

def wstecz_do_prowadzacy_main_haslo():
    zmien_haslo_frame.grid_forget()
    prowadzacy_main.grid(row=0, column=0)
